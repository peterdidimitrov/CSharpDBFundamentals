﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Invoices;User Id=sa;Password=Pass12345;TrustServerCertificate=true";
    }
}
