﻿namespace CarDealer.Data;

public static class Configuration
{
    public const string ConnectionString = @"Server=.;Database=CarDealer;User Id=sa;Password=Pass12345;TrustServerCertificate=true";
}
